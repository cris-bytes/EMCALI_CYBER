from pathlib import Path
import re

ROOT = Path.cwd()
print(f"Aplicando parche en: {ROOT}")

files = [ROOT/'core'/'analysis.py', ROOT/'core'/'state.py', ROOT/'pages'/'settings_page.py']
for p in files:
    if not p.exists():
        print(f"ADVERTENCIA: no existe {p}")

# 1) Cambia default duro de llama3.1:8b a phi3:mini en los archivos centrales
for rel in ['core/analysis.py', 'core/state.py', 'pages/settings_page.py', 'app.py']:
    p = ROOT/rel
    if p.exists():
        txt = p.read_text(encoding='utf-8', errors='ignore')
        old = txt
        txt = txt.replace('llama3.1:8b', 'phi3:mini')
        txt = txt.replace('llama3:8b', 'phi3:mini')
        txt = txt.replace('llama3', 'phi3:mini') if rel in ['core/analysis.py','core/state.py'] else txt
        if txt != old:
            bak = p.with_suffix(p.suffix + '.bak')
            if not bak.exists():
                bak.write_text(old, encoding='utf-8')
            p.write_text(txt, encoding='utf-8')
            print(f"Actualizado: {rel}")

# 2) Asegura que state.py tenga model_name y parametros editables mínimos
state = ROOT/'core'/'state.py'
if state.exists():
    txt = state.read_text(encoding='utf-8', errors='ignore')
    # Si hay un dict con backend/timeout, fuerza/añade llaves comunes de configuración.
    replacements = {
        "'backend': 'ollama'": "'backend': 'ollama',\n        'model_name': 'phi3:mini',\n        'ollama_base_url': 'http://127.0.0.1:11434',\n        'ollama_timeout': 600,\n        'fallback_enabled': False",
        '"backend": "ollama"': '"backend": "ollama",\n        "model_name": "phi3:mini",\n        "ollama_base_url": "http://127.0.0.1:11434",\n        "ollama_timeout": 600,\n        "fallback_enabled": false',
    }
    old = txt
    for a,b in replacements.items():
        if a in txt and 'model_name' not in txt[txt.find(a):txt.find(a)+300]:
            txt = txt.replace(a,b,1)
    if txt != old:
        state.write_text(txt, encoding='utf-8')
        print('Configuracion base reforzada en core/state.py')

# 3) Reescribe settings_page.py con una página configurable y compatible.
settings_page = ROOT/'pages'/'settings_page.py'
if settings_page.exists():
    old = settings_page.read_text(encoding='utf-8', errors='ignore')
    bak = settings_page.with_suffix(settings_page.suffix + '.bak')
    if not bak.exists():
        bak.write_text(old, encoding='utf-8')

    new = r'''import streamlit as st


def render_settings_page(settings=None):
    """Página de configuración LLM para EMCALI Cyber 2.0 Híbrido.
    Permite cambiar backend, modelo Ollama, URL, timeout y fallback sin tocar código.
    """
    if settings is None:
        settings = st.session_state.get("settings", {})

    st.title("⚙️ Configuración")
    st.subheader("Motor LLM híbrido")

    backend_options = ["ollama", "gemini", "offline"]
    current_backend = settings.get("backend", settings.get("BackendLLM", "ollama"))
    if current_backend not in backend_options:
        current_backend = "ollama"

    settings["backend"] = st.selectbox(
        "Backend LLM",
        backend_options,
        index=backend_options.index(current_backend),
        help="Use ollama para inferencia local; gemini para nube; offline para reglas internas sin LLM."
    )

    installed_defaults = [
        "phi3:mini",
        "tinyllama",
        "gemma:2b",
        "qwen2.5:3b",
        "mistral:7b",
        "llama3.1:8b",
    ]
    current_model = settings.get("model_name", settings.get("ollama_model", "phi3:mini"))
    if current_model not in installed_defaults:
        installed_defaults.insert(0, current_model)

    selected = st.selectbox(
        "Modelo Ollama activo",
        installed_defaults,
        index=installed_defaults.index(current_model),
        help="Para equipos Xeon/16-32 GB RAM se recomienda phi3:mini, tinyllama o gemma:2b."
    )
    custom = st.text_input(
        "Modelo personalizado Ollama opcional",
        value="",
        placeholder="Ejemplo: llama3.2:3b, deepseek-r1:1.5b, etc."
    ).strip()
    settings["model_name"] = custom or selected
    settings["ollama_model"] = settings["model_name"]

    settings["ollama_base_url"] = st.text_input(
        "URL Ollama",
        value=settings.get("ollama_base_url", "http://127.0.0.1:11434")
    )

    settings["ollama_timeout"] = st.number_input(
        "Timeout Ollama (segundos)",
        min_value=30,
        max_value=1800,
        value=int(settings.get("ollama_timeout", settings.get("timeout_ollama", 600))),
        step=30
    )
    settings["timeout_ollama"] = settings["ollama_timeout"]

    settings["fallback_enabled"] = st.toggle(
        "Activar fallback Gemini si Ollama falla",
        value=bool(settings.get("fallback_enabled", False))
    )
    settings["gemini_api_key"] = st.text_input(
        "Gemini API Key",
        value=settings.get("gemini_api_key", ""),
        type="password",
        help="Opcional. Si se deja vacío, la app no debe intentar Gemini."
    )

    st.session_state["settings"] = settings

    st.success(f"Modelo activo configurado: {settings['model_name']}")
    st.info("Guarde/cambie de módulo y vuelva a ejecutar el análisis. Si Ollama está abierto, la app usará este modelo.")

    with st.expander("Comandos útiles de Ollama"):
        st.code(f"ollama pull {settings['model_name']}\nollama run {settings['model_name']}\nollama list", language="bash")

    return settings


# Compatibilidad con apps que llaman main(), render() o page()
def main(settings=None):
    return render_settings_page(settings)


def render(settings=None):
    return render_settings_page(settings)


def page(settings=None):
    return render_settings_page(settings)
'''
    settings_page.write_text(new, encoding='utf-8')
    print('Reescrito: pages/settings_page.py')

# 4) Parchea analysis.py para que no intente Gemini si no está activado o no hay API key.
analysis = ROOT/'core'/'analysis.py'
if analysis.exists():
    txt = analysis.read_text(encoding='utf-8', errors='ignore')
    old = txt
    txt = txt.replace("settings.get('model_name', 'llama3.1:8b')", "settings.get('model_name', 'phi3:mini')")
    txt = txt.replace('settings.get("model_name", "llama3.1:8b")', 'settings.get("model_name", "phi3:mini")')
    # Parche mínimo: si aparece gemini_api_key y fallback, no rompe si no hay key. Conservador.
    if txt != old:
        analysis.write_text(txt, encoding='utf-8')
        print('Revisado: core/analysis.py')

print('\nParche finalizado. Ahora ejecute: streamlit run app.py')
